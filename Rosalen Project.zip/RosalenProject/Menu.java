import greenfoot.*;
// Somente um Menu.
public class Menu extends Actor
{
    public Menu (){
        getImage().scale(240,610);
    }

    public void act()
    {
        // Add your action code here.
    }
}
