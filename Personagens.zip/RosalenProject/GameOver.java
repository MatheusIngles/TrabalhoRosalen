import greenfoot.*;  
// Faz aparecer GameOver na tela quando for derrota.
public class GameOver extends Actor
{
    public GameOver(){
        getImage().scale(840,600);
    }

    public void act()
    {
        // Add your action code here.
    }
}
