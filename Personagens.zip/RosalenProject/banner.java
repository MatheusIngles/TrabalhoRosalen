import greenfoot.*;  
//Somente para criar o banner e a capa do jogo
public class banner extends Actor
{

    public banner(){
        getImage().scale(240,500);
    }

}
